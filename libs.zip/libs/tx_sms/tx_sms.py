import random

from . import settings
from qcloudsms_py import SmsSingleSender
from qcloudsms_py.httpclient import HTTPError


def get_code():
    code = ''
    for i in range(4):
        code += str(random.randint(0, 9))
    return code


def send_message(mobile, code):
    ssender = SmsSingleSender(settings.appid, settings.appkey)
    params = [code]
    try:
        result = ssender.send_with_param(86, mobile,
                                         settings.template_id, params, sign=settings.sms_sign, extend="", ext="")
        if result and result.get('result') == 0:
            return True
    except HTTPError as e:
        print(e)
    except Exception as e:
        print(e)
    print(result)
