import os
from django.http import FileResponse
from rest_framework.viewsets import ViewSet, GenericViewSet
from rest_framework.mixins import CreateModelMixin, ListModelMixin, UpdateModelMixin
from Album import settings
from Album.settings import BASE_DIR
from rest_framework.views import APIView
from api import models
from utils import serializers
from utils.response import APIResponse
import re
from rest_framework.decorators import action
from utils.throttles import SMSRateThrottle
from libs import tx_sms
from django.core.cache import cache
from utils.authentication import MyToken
from utils.paginations import PageNumberPagination
from utils.classify.classify import classify
from utils.identification import recognition, trace
from utils.video_create import create_video


class LoginViewSet(ViewSet):
    # 局部禁用认证、权限组件
    authentication_classes = ()
    permission_classes = ()

    @action(methods=['POST'], detail=False)
    def login(self, request, *args, **kwargs):
        serializer = serializers.LoginSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            token = serializer.context['token']
            # 拿到登录用户，直接走序列化过程，将要返回给前台的数据直接序列化好给前台
            user_id = serializer.context['user'].id
            return APIResponse(token=token, id=user_id)
        return APIResponse(code=0, msg=serializer.errors)

    @action(methods=['POST'], detail=False)
    def code_login(self, request, *args, **kwargs):
        serializer = serializers.MobileLoginSerializer(data=request.data, context={'request': request})
        if serializer.is_valid():
            token = serializer.context['token']
            # 拿到登录用户，直接走序列化过程，将要返回给前台的数据直接序列化好给前台
            user_id = serializer.context['user'].id
            return APIResponse(token=token, id=user_id)
        return APIResponse(code=0, msg=serializer.errors)

    @action(methods=['GET'], detail=False)
    def check(self, request, *args, **kwargs):
        mobile = request.query_params.get('mobile')
        if not mobile:
            return APIResponse(code=0, msg='请输入手机号')
        if not re.match(r'^1[3-9][0-9]{9}$', mobile):
            return APIResponse(code=0, msg='请输入正确手机号')
        try:
            models.User.objects.get(mobile=mobile)
            return APIResponse(code=1, msg='手机号可用')  # 手机号存在
        except:
            return APIResponse(code=0, msg='手机号不存在')  # 手机号不存在


class Send_msg(ViewSet):
    throttle_classes = (SMSRateThrottle,)

    def send(self, request, *args, **kwargs):
        mobile = request.query_params.get('mobile')
        if not mobile:
            return APIResponse(code=0, msg='请输入手机号')
        if not re.match(r'^1[3-9][0-9]{9}$', mobile):
            return APIResponse(code=0, msg='请输入正确手机号')
        code = tx_sms.get_code()
        res = tx_sms.send_message(mobile, code)

        if res:
            cache.set(settings.MOBILE_MSG_KET % mobile, code, 300)
            return APIResponse(code=1, msg='验证码发送成功')
        else:
            return APIResponse(code=0, msg='验证码发送失败')


class RegisterViewSet(GenericViewSet, CreateModelMixin):
    queryset = models.User.objects.all()
    serializer_class = serializers.RegisterSerializer

    def create(self, request, *args, **kwargs):
        res = super().create(request, *args, **kwargs)
        username = res.data.get('username')
        return APIResponse(code=1, msg='注册成功', username=username)


# 创建相簿
class AlbumViewSet(GenericViewSet):
    serializer_class = serializers.AlbumSerializer
    queryset = models.Album.objects.all()
    authentication_classes = (MyToken,)

    def create(self, request, *args, **kwargs):
        name = request.data.get('name')
        info = request.data.get('info')
        user_id = request.user.id
        print(user_id)
        user_id = models.User.objects.get(id=user_id)
        models.Album.objects.create(user=user_id, name=name, info=info)
        username = request.user.username
        return APIResponse(code=1, msg='相簿创建成功', name=name, username=username)


class AlbumShowViewSet(GenericViewSet, ListModelMixin):
    serializer_class = serializers.AlbumSerializer
    queryset = models.Album.objects.filter(is_delete=False).order_by('create_time')
    authentication_classes = (MyToken,)

    def list(self, request, *args, **kwargs):
        user_id = request.user.id
        album = models.Album.objects.filter(user=user_id).all()
        photo_ser = serializers.AlbumSerializer(instance=album, many=True)
        return APIResponse(code=1, msg='查询成功', data=photo_ser.data)


class AlbumPut(APIView):
    authentication_classes = (MyToken,)

    def post(self, request, pk):
        album_obj = models.Album.objects.filter(pk=pk).first()
        album_ser = serializers.AlbumSerializer(data=request.data, instance=album_obj)
        if album_ser.is_valid():
            album_ser.save()
            return APIResponse(code=1, msg='修改成功', data=album_ser.data)


# 查询所有
class PhotoView(GenericViewSet, ListModelMixin):
    serializer_class = serializers.PhotoSerializer
    queryset = models.Photo.objects.filter(is_delete=False).order_by('create_time')
    authentication_classes = (MyToken,)
    pagination_class = PageNumberPagination

    def list(self, request, *args, **kwargs):
        user_id = request.user.id
        photo = models.Photo.objects.filter(user=user_id).all()
        photo_ser = serializers.PhotoSerializer(instance=photo, many=True)
        return APIResponse(code=1, msg='查询成功', data=photo_ser.data)


class PhotoAView(GenericViewSet, ListModelMixin):
    serializer_class = serializers.PhotoSerializer
    queryset = models.Photo.objects.filter(is_delete=False).order_by('create_time')
    authentication_classes = (MyToken,)
    pagination_class = PageNumberPagination

    def list(self, request, *args, **kwargs):
        pk = kwargs.get('pk')
        photo = models.Photo.objects.filter(album=pk).all()
        photo_ser = serializers.PhotoSerializer(instance=photo, many=True)
        return APIResponse(code=1, msg='查询成功', data=photo_ser.data)


class PhotoPView(GenericViewSet, ListModelMixin):
    serializer_class = serializers.PhotoSerializer
    queryset = models.Photo.objects.filter(is_delete=False).order_by('create_time')
    authentication_classes = (MyToken,)
    pagination_class = PageNumberPagination

    def list(self, request, *args, **kwargs):
        pk = kwargs.get('pk')
        photo = models.Photo.objects.filter(pk=pk).first()
        photo_ser = serializers.PhotoSerializer(instance=photo)
        return APIResponse(code=1, msg='查询成功', data=photo_ser.data)


class AlbumDelete(APIView):
    def post(self, request):
        id = request.data.get('id')
        models.Album.objects.filter(id=id).delete()


class PhotoDelete(APIView):
    def post(self, request, *args, **kwargs):
        if isinstance(request.data, dict):
            id = request.data.get('id')
            models.Photo.objects.filter(id=id).delete()
        elif isinstance(request.data, list):
            for item in request.data:
                id = item.get('id')
                models.Photo.objects.filter(id=id).delete()
        return APIResponse(code=1, msg='删除成功')


class PhotoAddView(APIView):
    authentication_classes = (MyToken,)

    def post(self, request, *args, **kwargs):
        user_id = request.user.id
        print(user_id)
        if isinstance(request.data, dict):
            photo_ser = serializers.PhotoSerializer(data=request.data)
            photo_ser.is_valid(raise_exception=True)
            photo_ser.save()
        elif isinstance(request.data, list):
            photo_ser = serializers.PhotoSerializer(data=request.data, many=True)
            photo_ser.is_valid(raise_exception=True)
            photo_ser.save()

        photo_ser_list = []
        photo_ser_list.append(photo_ser.data)
        print(photo_ser_list)
        photo_type_list = []
        for ph in photo_ser_list:
            print(ph)
            p = ph.get('photo')
            path = str(BASE_DIR) + str(p)
            model_save_dir = str(BASE_DIR) + '/utils/classify/model/photo/'
            photo_type = classify(path, model_save_dir)
            print(photo_type)
            photo_type_list.append(photo_type)
            photo_id = ph.get('id')
            models.Photo.objects.filter(id=photo_id).update(type=photo_type, user=user_id)
        return APIResponse(code=1, msg='添加成功', data=photo_ser.data, photo_type=photo_type_list)


class FaceView(APIView):
    authentication_classes = (MyToken,)

    def post(self, request, *args, **kwargs):
        face_ser = serializers.GroupFaceSerializer(data=request.data)
        face_ser.is_valid(raise_exception=True)
        face_ser.save()
        path = str(BASE_DIR) + str(face_ser.data.get('group_face'))
        save_path = str(BASE_DIR) + '/media/faces'
        trace(path, save_path)
        path = '/media/faces/face_trace.jpg'
        return APIResponse(code=1, msg='成功', path=path)

    def get(self, request, *args, **kwargs):
        user_id = request.user.id
        print(user_id)
        group_face_obj = models.GroupFace.objects.last()
        face_obj = models.Face.objects.filter(user=user_id).last()
        group_face = group_face_obj.group_face
        face = face_obj.face
        print(group_face, face)
        group_face_path = str(BASE_DIR) + '/media/' + str(group_face)
        face_path = str(BASE_DIR) + '/media/' + str(face)
        save_path = str(BASE_DIR) + '/media/faces'
        res = recognition(group_face_path, face_path, save_path)
        return APIResponse(code=1, msg='成功', path=res)


class FaceAddView(GenericViewSet, ListModelMixin):
    serializer_class = serializers.FaceSerializer
    queryset = models.Photo.objects.filter(is_delete=False).order_by('create_time')
    authentication_classes = (MyToken,)

    def list(self, request, *args, **kwargs):
        user_id = request.user.id
        face = models.Face.objects.filter(user=user_id).all()
        face_ser = serializers.FaceSerializer(instance=face, many=True)
        return APIResponse(code=1, msg='查询成功', data=face_ser.data)

    def create(self, request, *args, **kwargs):
        user_id = request.user.id
        # user_id = models.User.objects.get(id=user_id)
        face_ser = serializers.FaceSerializer(data=request.data)
        face_ser.is_valid(raise_exception=True)
        face_ser.save()
        face_id = face_ser.data.get('id')
        models.Face.objects.filter(id=face_id).update(user=user_id)
        username = request.user.username
        return APIResponse(code=1, msg='人脸创建成功', face=face_ser.data, username=username, user_id=user_id)


class PhotoTView(GenericViewSet, ListModelMixin):
    serializer_class = serializers.PhotoSerializer
    queryset = models.Photo.objects.filter(is_delete=False).order_by('create_time')
    authentication_classes = (MyToken,)
    pagination_class = PageNumberPagination

    def list(self, request, *args, **kwargs):
        type = kwargs.get('type')
        photo = models.Photo.objects.filter(type=type).all()
        photo_ser = serializers.PhotoSerializer(instance=photo, many=True)
        return APIResponse(code=1, msg='查询成功', data=photo_ser.data)


class ImageListView(APIView):
    authentication_classes = (MyToken,)

    def post(self, request, *args, **kwargs):
        if isinstance(request.data, dict):
            img_ser = serializers.ImageListSerializer(data=request.data)
            img_ser.is_valid(raise_exception=True)
            img_ser.save()
        elif isinstance(request.data, list):
            img_ser = serializers.ImageListSerializer(data=request.data, many=True)
            img_ser.is_valid(raise_exception=True)
            img_ser.save()
        return APIResponse(code=1, msg='添加成功', data=img_ser.data)


class BGMView(GenericViewSet, CreateModelMixin):
    queryset = models.BGM.objects.all()
    serializer_class = serializers.BGMSerializer
    authentication_classes = (MyToken,)


class Video(APIView):
    def get(self, request, *args, **kwargs):
        # path = BASE_DIR + '/media/res.mp4'
        # while path:
        #     os.remove(path)
        bgm_obj = models.BGM.objects.last()
        bgm = bgm_obj.bgm
        img_path = BASE_DIR + '/media/image_list'
        bgm_path = BASE_DIR + '/media/' + str(bgm)
        video_path = BASE_DIR + '/media/res.mp4'
        create_video(img_path, video_path, bgm_path)
        os.remove(bgm_path)
        for item in os.listdir(img_path):
            file_path = BASE_DIR + '/media/image_list/' + str(item)
            os.remove(file_path)
        os.rmdir(img_path)
        return APIResponse(code=1, msg='合成回忆录成功', path=video_path)


class VideoDownload(APIView):
    authentication_classes = (MyToken,)

    def get(self, request):
        path = BASE_DIR + '/media/res.mp4'
        file = open(path, 'rb')
        response = FileResponse(file)
        response['Content-Type'] = 'application/octet-stream'
        response['Content-Disposition'] = 'attachment;filename="video.mp4"'
        return response


class PhotoDownload(APIView):
    authentication_classes = (MyToken,)

    def post(self, request, *args, **kwargs):
        if isinstance(request.data, dict):
            id = request.data.get('id')
            photo_obj = models.Photo.objects.filter(id=id).first()
            photo_path = photo_obj.photo
            photo_name = str(photo_obj).lstrip('photo/')
            path = BASE_DIR + '/media/' + str(photo_path)
            file = open(path, 'rb')
            response = FileResponse(file)
            response['Content-Type'] = 'application/octet-stream'
            response['Content-Disposition'] = 'attachment;filename="{}"'.format(photo_name)
            return response
        elif isinstance(request.data, list):
            for item in request.data:
                id = item.get('id')
                photo_obj = models.Photo.objects.filter(id=id).first()
                photo_path = photo_obj.photo
                photo_name = str(photo_obj).lstrip('photo/')
                path = BASE_DIR + '/media/' + str(photo_path)
                file = open(path, 'rb')
                response = FileResponse(file)
                response['Content-Type'] = 'application/octet-stream'
                response['Content-Disposition'] = 'attachment;filename="{}"'.format(photo_name)
                return response
