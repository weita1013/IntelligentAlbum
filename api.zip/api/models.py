from django.db import models
from django.contrib.auth.models import AbstractUser


class User(AbstractUser):
    mobile = models.CharField(max_length=11)
    icon = models.ImageField(upload_to='icon', default='icon/default.png')


class Photo(models.Model):
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='上传时间')
    is_delete = models.BooleanField(default=False, verbose_name='是否删除')
    user = models.ForeignKey(to='User', on_delete=models.CASCADE, null=True)
    photo = models.ImageField(upload_to='photos', verbose_name='照片')
    album = models.ForeignKey(to='Album', on_delete=models.CASCADE, null=True)
    type = models.IntegerField(choices=((0, '人物'), (1, '动物'), (2, '风景'), (3, '交通'), (4, '美食'), (5, '私人照片分发')),
                               verbose_name='照片分类',
                               null=True)


class Album(models.Model):
    name = models.CharField(max_length=32, verbose_name='相簿名', unique=True)
    info = models.TextField(verbose_name='相簿介绍', null=True)
    user = models.ForeignKey(to='User', on_delete=models.CASCADE, null=True)
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='创建时间')
    is_delete = models.BooleanField(default=False, verbose_name='是否删除')


class Face(models.Model):
    user = models.ForeignKey(to='User', on_delete=models.CASCADE, null=True)
    face = models.ImageField(upload_to='user_face', verbose_name='人脸正面照')


class GroupFace(models.Model):
    user = models.ForeignKey(to='User', on_delete=models.CASCADE, null=True)
    group_face = models.ImageField(upload_to='group_face', verbose_name='集体照')


class ImageList(models.Model):
    image = models.ImageField(upload_to='image_list', verbose_name='图片')


class BGM(models.Model):
    bgm = models.FileField(upload_to='bgm', verbose_name='背景音乐')
