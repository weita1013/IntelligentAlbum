import xadmin
from xadmin import views
from api import models


class GlobalSettings(object):
    """xadmin的全局配置"""
    site_title = "智能云端相册"  # 设置站点标题
    site_footer = "太科大315"  # 设置站点的页脚


xadmin.site.register(views.CommAdminView, GlobalSettings)
xadmin.site.register(models.Album)
xadmin.site.register(models.Photo)
