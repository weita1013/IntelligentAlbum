from django.urls import path, include, re_path
from api import views
from rest_framework.routers import SimpleRouter

# 自动生成路由
router = SimpleRouter()
router.register('', views.LoginViewSet, 'login')
router.register('register', views.RegisterViewSet)
router.register('album', views.AlbumViewSet)
router.register('album_show', views.AlbumShowViewSet)
router.register('photo', views.PhotoView)
router.register('bgm', views.BGMView)

urlpatterns = [
    path('', include(router.urls)),
    path('mobile/', views.Send_msg.as_view({'get': 'send'})),
    path('photo_add/', views.PhotoAddView.as_view()),
    path('image_list/', views.ImageListView.as_view()),
    path('face/', views.FaceView.as_view()),
    path('video/', views.Video.as_view()),
    path('download_video/', views.VideoDownload.as_view()),
    path('download_photo/', views.PhotoDownload.as_view()),
    path('photo_delete/', views.PhotoDelete.as_view()),
    path('album_delete/', views.AlbumDelete.as_view()),
    re_path('^album_put/(?P<pk>\d+)/', views.AlbumPut.as_view()),
    re_path(r'^photo_a/(?P<pk>\d+)/', views.PhotoAView.as_view({'get': 'list'})),
    re_path(r'^photo_p/(?P<pk>\d+)/', views.PhotoPView.as_view({'get': 'list'})),
    re_path(r'^photo_t/(?P<type>\d+)/', views.PhotoTView.as_view({'get': 'list'})),
    path('face_add/', views.FaceAddView.as_view({'get': 'list', 'post': 'create'})),
]
