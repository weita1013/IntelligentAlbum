from django.urls import path, include, re_path
import xadmin
from xadmin.plugins import xversion
from django.views.static import serve
from django.conf import settings
xadmin.autodiscover()
xversion.register_models()
urlpatterns = [
    path('xadmin/', xadmin.site.urls),
    re_path('media/(?P<path>.*)', serve, {'document_root': settings.MEDIA_ROOT}),
    path('api/', include('api.urls'))
]
