from PIL import Image
import paddle
import paddle.fluid as fluid
import numpy
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

paddle.enable_static()


def classify(test_img, model_save_dir):
    name_dict = {'people': 0, 'animal': 1, 'landscape': 2,
                 'vehicle': 3, 'food': 4}
    place = fluid.CPUPlace()
    infer_exe = fluid.Executor(place)

    # model_save_dir = 'model/photo/'

    # 读取图片，调整尺寸归一化处理
    def load_image(path):
        img = paddle.dataset.image.load_and_transform(
            path, 100, 100, False).astype('float32')
        img = img / 255.0
        return img

    infer_imgs = []  # 图像数据列表
    infer_imgs.append(load_image(test_img))  # 加载图像数据，添加到列表
    infer_imgs = numpy.array(infer_imgs)  # 转换成array

    # 加载模型
    [infer_program, feed_target_names, fetch_targets] = fluid.io.load_inference_model(model_save_dir, infer_exe)
    # 现显示原始图片
    img = Image.open(test_img)  # 打开图片
    plt.imshow(img)  # 显示原始图片
    plt.show()
    # 执行预测
    results = infer_exe.run(infer_program,
                            feed={feed_target_names[0]: infer_imgs},
                            fetch_list=fetch_targets)
    # print(results)  # result为数组，包含每个类别的概率
    result = numpy.argmax(results[0])  # 获取最大值的索引
    for k, v in name_dict.items():
        if result == v:
            print('预测结果为：', k, v)
            return v

# from Album.settings import BASE_DIR
# # BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# print(BASE_DIR)
# # p = '4_wRkF1Ky.jpg'
# # p = '4_wRkF1Ky.jpg'
# p = '/Users/weita/PycharmProjects/Album/media/photos/4_wRkF1Ky.jpg'
# classify(p)
# print(classify(p))
